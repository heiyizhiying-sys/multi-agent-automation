
# multi-agent-automation 多智能体自动化系统示例

这是一个多Agent协作的自动化运营系统示例。

## 功能
- 多Agent任务调度
- 异步事件驱动架构
- 支持任务优先级和失败重试

## 运行方式
```bash
pip install -r requirements.txt
python main.py
```

## 证明截图
- docs/example_screenshot.png
