
import asyncio
import random

class Agent:
    def __init__(self, name, manager):
        self.name = name
        self.manager = manager
        self.running = True

    async def run(self):
        while self.running:
            task = await self.manager.get_task()
            if not task:
                await asyncio.sleep(0.1)
                continue
            await self.execute_task(task)

    async def execute_task(self, task):
        print(f"[{self.name}] 开始执行任务: {task.name}")
        task.status = 'running'
        try:
            if task.task_type == 'compute':
                await asyncio.sleep(random.uniform(0.5, 1.5))
                result = sum(i*i for i in range(1000))
            elif task.task_type == 'io':
                await asyncio.sleep(random.uniform(0.5, 2.0))
            elif task.task_type == 'network':
                await asyncio.sleep(random.uniform(1, 3))
            task.status = 'completed'
            print(f"[{self.name}] 完成任务: {task.name}")
        except Exception:
            task.retries += 1
            task.status = 'failed'
            print(f"[{self.name}] 执行失败: {task.name} 重试 {task.retries}")
            if task.retries < task.max_retries:
                await self.manager.add_task(task)
        finally:
            await self.manager.report_task(task, self)

    def stop(self):
        self.running = False
