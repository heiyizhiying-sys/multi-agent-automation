
import asyncio
from agent import Agent
from manager import Manager
from tasks import Task

async def main():
    manager = Manager()
    task_list = [Task(f"任务-{i}", task_type) for i, task_type in enumerate(["compute", "io", "network"]*7, start=1)]
    for task in task_list:
        await manager.add_task(task)

    agents = [Agent(f"Agent-{i}", manager) for i in range(1, 6)]
    agent_tasks = [asyncio.create_task(agent.run()) for agent in agents]

    while not manager.tasks.empty():
        await asyncio.sleep(0.1)

    for agent in agents:
        agent.stop()

    await asyncio.gather(*agent_tasks)

    print("\n=== 任务完成情况 ===")
    for agent_name, tasks in manager.completed_tasks.items():
        print(f"{agent_name}: {tasks}")
    print("失败任务:", manager.failed_tasks)

if __name__ == "__main__":
    asyncio.run(main())
