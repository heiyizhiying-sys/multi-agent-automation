
import asyncio

class Manager:
    def __init__(self):
        self.tasks = asyncio.PriorityQueue()
        self.completed_tasks = {}
        self.failed_tasks = []

    async def add_task(self, task):
        await self.tasks.put((task.priority, task))

    async def get_task(self):
        if self.tasks.empty():
            return None
        _, task = await self.tasks.get()
        return task

    async def report_task(self, task, agent):
        if task.status == 'completed':
            if agent.name not in self.completed_tasks:
                self.completed_tasks[agent.name] = []
            self.completed_tasks[agent.name].append(task.name)
        elif task.status == 'failed' and task.retries >= task.max_retries:
            self.failed_tasks.append(task.name)
