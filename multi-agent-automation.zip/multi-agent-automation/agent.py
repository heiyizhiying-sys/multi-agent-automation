import asyncio
import random
import os
from config import TaskType, TaskStatus
from logger import get_logger


class Agent:
    def __init__(self, name, manager, config):
        self.name = name
        self.manager = manager
        self.config = config
        self.running = True
        self.current_load = 0
        self.completed_count = 0

        self.skills = {
            TaskType.COMPUTE: self._execute_compute,
            TaskType.IO: self._execute_io,
            TaskType.NETWORK: self._execute_network,
            TaskType.COMPLEX: self._execute_complex,
        }

        self.logger = get_logger(f"agent.{name}")

    async def run(self):
        self.logger.info(f"Agent 启动")
        while self.running:
            task = await self.manager.get_task(self.name)
            if not task:
                if not self.manager.has_work:
                    break
                await asyncio.sleep(0.05)
                continue

            self.current_load += 1
            await self._execute(task)
            self.current_load -= 1
            self.completed_count += 1

        self.logger.info(f"Agent 停止 完成任务数={self.completed_count}")

    def stop(self):
        self.running = False

    async def _execute(self, task):
        skill = self.skills.get(task.task_type, self._execute_default)
        self.logger.info(f"执行开始: {task.name} type={task.task_type.value}")
        try:
            await skill(task)
            task.status = TaskStatus.COMPLETED
            await self.manager.complete_task(task)
        except Exception as e:
            self.logger.warning(f"执行异常: {task.name} error={e}")
            await self.manager.fail_task(task)

    async def _execute_compute(self, task):
        await asyncio.sleep(random.uniform(0.2, 0.8))
        _ = sum(i * i for i in range(5000))
        await asyncio.sleep(random.uniform(0.1, 0.3))

    async def _execute_io(self, task):
        await asyncio.sleep(random.uniform(0.3, 1.0))
        os.makedirs(self.config.simulate_io_dir, exist_ok=True)
        temp_file = os.path.join(self.config.simulate_io_dir, f"task_{task.id}.tmp")
        data = f"task_data_{task.id}_" + "x" * 1024
        try:
            with open(temp_file, "w") as f:
                f.write(data)
            with open(temp_file, "r") as f:
                _ = f.read()
        finally:
            if os.path.exists(temp_file):
                os.remove(temp_file)

    async def _execute_network(self, task):
        duration = random.uniform(0.5, 2.0)
        elapsed = 0.0
        step = 0.1
        while elapsed < duration:
            await asyncio.sleep(step)
            elapsed += step
            if random.random() < 0.05:
                raise Exception(f"网络超时: {task.name}")

    async def _execute_complex(self, task):
        await asyncio.sleep(random.uniform(0.5, 1.0))

    async def _execute_default(self, task):
        await asyncio.sleep(random.uniform(0.3, 0.6))
