from dataclasses import dataclass, field
from enum import Enum


class TaskType(Enum):
    COMPUTE = "compute"
    IO = "io"
    NETWORK = "network"
    COMPLEX = "complex"


class TaskStatus(Enum):
    PENDING = "pending"
    WAITING_DEPS = "waiting_deps"
    READY = "ready"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"


@dataclass
class SystemConfig:
    agent_count: int = 5
    max_retries: int = 3
    task_timeout: float = 30.0
    monitor_interval: float = 0.5
    log_file: str = "audit.log"
    log_level: str = "INFO"
    simulate_io_dir: str = "data"
