import logging
import json
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler


class JsonFormatter(logging.Formatter):
    def format(self, record):
        log_entry = {
            "timestamp": datetime.now().strftime("%Y-%m-%d %H:%M:%S.%f")[:-3],
            "level": record.levelname,
            "module": record.name,
            "message": record.getMessage(),
        }
        if record.exc_info and record.exc_info[1]:
            log_entry["exception"] = str(record.exc_info[1])
        return json.dumps(log_entry, ensure_ascii=False)


def setup_logging(config):
    root = logging.getLogger("automation")
    root.setLevel(getattr(logging, config.log_level))
    root.handlers.clear()

    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.WARNING)
    console_fmt = logging.Formatter("%(asctime)s [%(levelname)s] %(message)s", datefmt="%H:%M:%S")
    console_handler.setFormatter(console_fmt)
    root.addHandler(console_handler)

    audit_path = config.log_file
    os.makedirs(os.path.dirname(audit_path) if os.path.dirname(audit_path) else ".", exist_ok=True)
    file_handler = RotatingFileHandler(audit_path, maxBytes=10 * 1024 * 1024, backupCount=5, encoding="utf-8")
    file_handler.setLevel(logging.DEBUG)
    file_handler.setFormatter(JsonFormatter())
    root.addHandler(file_handler)

    return root


def get_logger(name):
    return logging.getLogger(f"automation.{name}")
