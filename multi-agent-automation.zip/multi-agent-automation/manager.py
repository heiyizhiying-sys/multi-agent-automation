import asyncio
import time
from collections import defaultdict
from config import TaskStatus
from logger import get_logger

logger = get_logger("manager")


class Manager:
    def __init__(self):
        self.pending_queue = []
        self.ready_queue = asyncio.PriorityQueue()
        self.running_tasks = {}
        self.completed_tasks = defaultdict(list)
        self.failed_tasks = []

        self.stats = {
            "total_submitted": 0,
            "total_completed": 0,
            "total_failed": 0,
            "total_retried": 0,
            "start_time": time.time(),
            "completion_times": [],
            "agent_tasks": defaultdict(int),
        }

    async def add_task(self, task):
        self.stats["total_submitted"] += 1
        task.status = TaskStatus.PENDING
        logger.info(f"任务提交: id={task.id} name={task.name} type={task.task_type.value} "
                     f"priority={task.priority} deps={task.dependencies}")

        unsatisfied = self._get_unsatisfied_deps(task)
        if unsatisfied:
            task.status = TaskStatus.WAITING_DEPS
            self.pending_queue.append(task)
            logger.debug(f"任务 {task.name} 等待依赖: {unsatisfied}")
        else:
            task.status = TaskStatus.READY
            await self._enqueue_ready(task)

    async def add_tasks_batch(self, tasks):
        for task in tasks:
            await self.add_task(task)

    async def get_task(self, agent_name):
        if self.ready_queue.empty():
            return None
        _, task = await self.ready_queue.get()
        task.status = TaskStatus.RUNNING
        task.assigned_agent = agent_name
        task.started_at = time.time()
        self.running_tasks[task.id] = task
        self.stats["agent_tasks"][agent_name] += 1
        logger.info(f"任务分配: {task.name} → {agent_name} (队列剩余: {self.ready_queue.qsize()})")
        return task

    async def complete_task(self, task):
        task.status = TaskStatus.COMPLETED
        task.completed_at = time.time()
        task.duration = task.completed_at - task.started_at
        self.running_tasks.pop(task.id, None)

        self.stats["total_completed"] += 1
        self.stats["completion_times"].append(task.duration)
        self.completed_tasks[task.assigned_agent].append(task.name)
        logger.info(f"任务完成: {task.name} agent={task.assigned_agent} "
                     f"耗时={task.duration:.3f}s")

        await self._resolve_dependencies(task)

        if task.subtasks:
            logger.info(f"协作任务 {task.name} 拆分为 {len(task.subtasks)} 个子任务")
            for sub in task.subtasks:
                sub.priority = task.priority
                await self.add_task(sub)

    async def fail_task(self, task):
        task.retries += 1
        self.running_tasks.pop(task.id, None)

        if task.retries < task.max_retries:
            task.status = TaskStatus.PENDING
            self.stats["total_retried"] += 1
            logger.warning(f"任务重试: {task.name} 第{task.retries}次 (最多{task.max_retries}次)")
            await self.add_task(task)
        else:
            task.status = TaskStatus.FAILED
            task.completed_at = time.time()
            self.stats["total_failed"] += 1
            self.failed_tasks.append(task.name)
            logger.error(f"任务最终失败: {task.name} 已重试{task.max_retries}次")

    def get_stats(self):
        elapsed = time.time() - self.stats["start_time"]
        completed = self.stats["total_completed"]
        throughput = completed / elapsed if elapsed > 0 else 0
        avg_duration = (sum(self.stats["completion_times"]) / len(self.stats["completion_times"])
                        if self.stats["completion_times"] else 0)
        return {
            "elapsed": elapsed,
            "completed": completed,
            "failed": self.stats["total_failed"],
            "retried": self.stats["total_retried"],
            "pending_deps": len(self.pending_queue),
            "ready": self.ready_queue.qsize(),
            "running": len(self.running_tasks),
            "throughput": throughput,
            "avg_duration": avg_duration,
            "agent_distribution": dict(self.stats["agent_tasks"]),
        }

    @property
    def has_work(self):
        return (not self.ready_queue.empty() or
                len(self.running_tasks) > 0 or
                len(self.pending_queue) > 0)

    @property
    def all_done(self):
        return (self.ready_queue.empty() and
                len(self.running_tasks) == 0 and
                len(self.pending_queue) == 0)

    async def _enqueue_ready(self, task):
        task.status = TaskStatus.READY
        await self.ready_queue.put((task.priority, task))

    async def _resolve_dependencies(self, completed_task):
        newly_ready = []
        for task in self.pending_queue[:]:
            if completed_task.name in task.dependencies:
                task.dependencies.remove(completed_task.name)
            if not task.dependencies:
                newly_ready.append(task)
                self.pending_queue.remove(task)

        for task in newly_ready:
            logger.debug(f"依赖满足: {task.name} 变为就绪")
            await self._enqueue_ready(task)

    def _get_unsatisfied_deps(self, task):
        completed_names = set()
        for names in self.completed_tasks.values():
            completed_names.update(names)
        return [d for d in task.dependencies if d not in completed_names]
