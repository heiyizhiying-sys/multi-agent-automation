import time
from config import TaskType, TaskStatus


class Task:
    _id_counter = 0

    def __init__(self, name, task_type, priority=1, max_retries=3,
                 dependencies=None, subtasks=None, timeout=None, required_skills=None):
        Task._id_counter += 1
        self.id = Task._id_counter
        self.name = name
        self.task_type = TaskType(task_type) if isinstance(task_type, str) else task_type
        self.priority = priority
        self.status = TaskStatus.PENDING
        self.retries = 0
        self.max_retries = max_retries
        self.dependencies = dependencies or []
        self.subtasks = subtasks or []
        self.timeout = timeout
        self.required_skills = required_skills or []
        self.assigned_agent = None

        self.created_at = time.time()
        self.started_at = None
        self.completed_at = None
        self.duration = None

    def __lt__(self, other):
        return self.priority < other.priority

    @property
    def is_ready(self):
        return self.status == TaskStatus.READY

    @property
    def is_completed(self):
        return self.status == TaskStatus.COMPLETED

    @property
    def is_failed(self):
        return self.status == TaskStatus.FAILED

    @property
    def all_deps_satisfied(self):
        return len(self.dependencies) == 0
