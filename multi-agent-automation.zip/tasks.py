
class Task:
    def __init__(self, name, task_type, priority=1, max_retries=3):
        self.name = name
        self.task_type = task_type
        self.priority = priority
        self.status = 'pending'
        self.retries = 0
        self.max_retries = max_retries

    def __lt__(self, other):
        return self.priority < other.priority
